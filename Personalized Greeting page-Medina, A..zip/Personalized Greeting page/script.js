document.addEventListener('DOMContentLoaded', function() {

    
    var form = document.getElementById('nameForm');
    var input = document.getElementById('nameInput');
    var greetingDiv = document.getElementById('greetingMsg');

    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        var name = input.value.trim();

        
        if (name) {
            greetingDiv.textContent = "Hello, " + name + "! Thank you for visiting my webpage!";
            greetingDiv.classList.remove('hidden');
        } else {
            greetingDiv.classList.add('hidden');
        }
    });

});

